#include <winsock2.h>
#include <ws2tcpip.h>
#include <iostream>
#include <string.h>

#pragma comment(lib, "ws2_32.lib")


int inet_pton_ipv4(int af, const char *src, void *dst)
{
    if (af == AF_INET)
    {
        unsigned long addr = inet_addr(src);
        if (addr == INADDR_NONE) return 0;
        ((struct in_addr *)dst)->s_addr = addr;
        return 1;
    }
    return -1; 
}

int main()
{
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);

    // Create UDP socket
    SOCKET sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock == INVALID_SOCKET)
    {
        std::cerr << "Socket creation failed: " << WSAGetLastError() << std::endl;
        WSACleanup();
        return 1;
    }

    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(8080);

    if (inet_pton_ipv4(AF_INET, "192.168.137.99", &serv_addr.sin_addr) <= 0)
    {
        std::cerr << "Invalid address" << std::endl;
        closesocket(sock);
        WSACleanup();
        return 1;
    }

    // Send message using UDP
    const char *hello = "Hello from UDP Client!";
    int sendResult = sendto(sock, hello, (int)strlen(hello), 0,
                            (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    if (sendResult == SOCKET_ERROR)
    {
        std::cerr << "Send failed: " << WSAGetLastError() << std::endl;
        closesocket(sock);
        WSACleanup();
        return 1;
    }
    std::cout << "Hello message sent via UDP" << std::endl;

    // Receive response
    char buffer[1024] = {0};
    int serv_addr_len = sizeof(serv_addr);
    int valread = recvfrom(sock, buffer, sizeof(buffer), 0,
                           (struct sockaddr *)&serv_addr, &serv_addr_len);
    if (valread > 0)
    {
        buffer[valread] = '\0';
        std::cout << "Server: " << buffer << std::endl;
    }
    else
    {
        std::cerr << "Receive failed: " << WSAGetLastError() << std::endl;
    }

    closesocket(sock);
    WSACleanup();
    return 0;
}