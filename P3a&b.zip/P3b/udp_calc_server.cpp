#include <winsock2.h>
#include <ws2tcpip.h>
#include <iostream>
#include <cstring>
#include <cmath>

#pragma comment(lib, "ws2_32.lib")

#define PORT 9001
#define BUF_SIZE 1024

double toRadians(double value, bool isDeg) {
    return isDeg ? value * M_PI / 180.0 : value;
}

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "WSAStartup failed" << std::endl;
        return 1;
    }

    SOCKET sockfd;
    char buffer[BUF_SIZE];
    struct sockaddr_in servaddr, cliaddr;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == INVALID_SOCKET) {
        std::cerr << "Socket creation failed: " << WSAGetLastError() << std::endl;
        WSACleanup();
        return 1;
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(PORT);

    if (bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) == SOCKET_ERROR) {
        std::cerr << "Bind failed: " << WSAGetLastError() << std::endl;
        closesocket(sockfd);
        WSACleanup();
        return 1;
    }

    std::cout << " UDP Math Server listening on port " << PORT << "..." << std::endl;

    int len = sizeof(cliaddr);
    while (true) {
        int n = recvfrom(sockfd, buffer, BUF_SIZE, 0, (struct sockaddr *)&cliaddr, &len);
        if (n == SOCKET_ERROR) {
            std::cerr << "recvfrom failed: " << WSAGetLastError() << std::endl;
            break;
        }

        buffer[n] = '\0';
        std::string input(buffer);

        std::cout << " Client Request: " << input << std::endl;

        if (input == "quit") {
            std::cout << " Client requested termination." << std::endl;
            break;
        }

        char func[10], unit[10] = "rad";
        double value = 0.0;
        int parsed = sscanf(buffer, "%s %lf %s", func, &value, unit);

        bool isDeg = (strcmp(unit, "deg") == 0);
        double result = 0.0;

        if (parsed >= 2) {
            if (strcmp(func, "sin") == 0)
                result = sin(toRadians(value, isDeg));
            else if (strcmp(func, "cos") == 0)
                result = cos(toRadians(value, isDeg));
            else if (strcmp(func, "tan") == 0)
                result = tan(toRadians(value, isDeg));
            else
                snprintf(buffer, BUF_SIZE, "Invalid function requested: %s", func);

            snprintf(buffer, BUF_SIZE, "Request: %s | Result: %.6f", input.c_str(), result);
        } else {
            snprintf(buffer, BUF_SIZE, "Invalid input format: %s", input.c_str());
        }

        // Send back the combined response
        sendto(sockfd, buffer, (int)strlen(buffer), 0, (struct sockaddr *)&cliaddr, len);
        std::cout << "Response sent: " << buffer << std::endl;
    }

    closesocket(sockfd);
    WSACleanup();
    return 0;
}