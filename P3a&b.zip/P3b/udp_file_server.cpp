#include <iostream>
#include <fstream>
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")

#define PORT 9002
#define BUF_SIZE 1024

int main() {
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in server_addr, client_addr;
    int client_len = sizeof(client_addr);
    char buffer[BUF_SIZE];

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        std::cerr << "WSAStartup failed" << std::endl;
        return 1;
    }

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == INVALID_SOCKET) {
        std::cerr << "Socket creation failed" << std::endl;
        WSACleanup();
        return 1;
    }

    // Setup address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind
    if (bind(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        std::cerr << "Bind failed" << std::endl;
        closesocket(sockfd);
        WSACleanup();
        return 1;
    }

    std::cout << "UDP File Server running on port " << PORT << std::endl;

    // Receive filename request from client
    int bytesReceived = recvfrom(sockfd, buffer, BUF_SIZE - 1, 0,
                                 (struct sockaddr*)&client_addr, &client_len);
    if (bytesReceived == SOCKET_ERROR) {
        std::cerr << "Failed to receive filename" << std::endl;
        closesocket(sockfd);
        WSACleanup();
        return 1;
    }
    buffer[bytesReceived] = '\0';
    std::string filename = buffer;
    std::cout << "Requested file: " << filename << std::endl;

    std::ifstream file(filename, std::ios::binary);
    if (!file) {
        std::cerr << "File not found: " << filename << std::endl;
        std::string msg = "ERROR: File not found";
        sendto(sockfd, msg.c_str(), msg.size(), 0,
               (struct sockaddr*)&client_addr, client_len);
        closesocket(sockfd);
        WSACleanup();
        return 1;
    }

    // Send file in chunks
    while (!file.eof()) {
        file.read(buffer, BUF_SIZE);
        int bytesToSend = file.gcount();
        sendto(sockfd, buffer, bytesToSend, 0,
               (struct sockaddr*)&client_addr, client_len);
    }

    std::cout << "File sent successfully over UDP." << std::endl;

    file.close();
    closesocket(sockfd);
    WSACleanup();
    return 0;
}
